//package com.example.cafeInfo.Service;
//
//
//import com.example.cafeInfo.Entity.CafeUploadEntity;
//import com.example.cafeInfo.Repository.CafeUploadRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//@Service
//public class CafeUploadService {
//
//    private final CafeUploadRepository cafeUploadRepository;
//
//    @Autowired
//    public CafeUploadService(CafeUploadRepository cafeUploadRepository) {
//        this.cafeUploadRepository = cafeUploadRepository;
//    }
//
//
//
//    public CafeUploadEntity saveCafe(CafeUploadEntity cafeUploadEntity) {
//        return cafeUploadRepository.save(cafeUploadEntity);  // 카페 정보를 DB에 저장
//    }
//
//    // 모든 카페 정보 조회
//    public Iterable<CafeUploadEntity> getAllCafes() {
//        return cafeUploadRepository.findAll();  // 모든 카페 정보 반환
//    }
//}
//
//
