package com.example.cafeInfo.Repository;

import com.example.cafeInfo.Entity.CafeUploadEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CafeUploadRepository extends JpaRepository<CafeUploadEntity, Long> {
}
