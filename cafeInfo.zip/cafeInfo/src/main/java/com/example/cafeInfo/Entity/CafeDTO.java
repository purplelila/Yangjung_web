package com.example.cafeInfo.Entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@Getter
@Setter

public class CafeDTO {
    private Long id;
    private String name;
    private String title;
    private String place;
    private String content;
    private String sns;
    private String phone;
    private Map<String, String> cafeHours;
    private List<String> imgURLs;
    private List<String> imgNames;

//    private List<MultipartFile> images;

    public CafeDTO() {}

    // Getter & Setter 자동 생성 (IDE에서 Alt+Insert 또는 마우스 우클릭 → Generate → Getter & Setter)
}

