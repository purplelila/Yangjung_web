package com.example.cafeInfo.Entity;

import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Map;

@Getter
@Setter

public class CafeDTO {
    private String name;
    private String title;
    private String place;
    private String content;
    private String sns;
    private String phone;
    private Map<String, String> cafeHours;
    private List<String> imgURLs;
    private List<String> imgNames;

    public CafeDTO() {}

    // Getter & Setter 자동 생성 (IDE에서 Alt+Insert 또는 마우스 우클릭 → Generate → Getter & Setter)

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getSns() {
        return sns;
    }

    public void setSns(String sns) {
        this.sns = sns;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Map<String, String> getCafeHours() {
        return cafeHours;
    }

    public void setCafeHours(Map<String, String> cafeHours) {
        this.cafeHours = cafeHours;
    }

    public List<String> getImgURLs() {
        return imgURLs;
    }

    public void setImgURLs(List<String> imgURLs) {
        this.imgURLs = imgURLs;
    }

    public List<String> getImgNames() {
        return imgNames;
    }

    public void setImgNames(List<String> imgNames) {
        this.imgNames = imgNames;
    }
}

