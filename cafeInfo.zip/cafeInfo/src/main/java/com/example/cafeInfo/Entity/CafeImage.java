package com.example.cafeInfo.Entity;

import jakarta.persistence.Embeddable;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Embeddable
@Getter
@Setter
public class CafeImage implements Serializable {
    private String imgURL;
    private String imgName;

    public CafeImage() {}

    public CafeImage(String imgURL, String imgName) {
        this.imgURL = imgURL;
        this.imgName = imgName;
    }
}


