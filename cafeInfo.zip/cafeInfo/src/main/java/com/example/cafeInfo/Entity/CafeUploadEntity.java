package com.example.cafeInfo.Entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Map;

@Entity
@Getter
@Setter
public class CafeUploadEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String title;

    private String sns;

    @Column(nullable = false)
    private String place;

    @Column(nullable = false)
    private String content;

    @Column(nullable = false)
    private String phone;

    @ElementCollection
    @CollectionTable(name = "cafe_hours", joinColumns = @JoinColumn(name = "cafe_upload_id"))
    @Column(name = "day_hour")
    private Map<String, String> cafeHours;

    @ElementCollection
    @CollectionTable(name = "cafe_images", joinColumns = @JoinColumn(name = "cafe_upload_id"))
    @Column(name = "img_url")
    private List<String> imgURLs;

    @ElementCollection
    @CollectionTable(name = "cafe_images", joinColumns = @JoinColumn(name = "cafe_upload_id"))
    @Column(name = "img_name")
    private List<String> imgNames;

    // 기본 생성자 (JPA에서 꼭 필요함)
    public CafeUploadEntity() {}

    // 모든 필드를 위한 Getter/Setter
    public Long getId() { return id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getPlace() { return place; }
    public void setPlace(String place) { this.place = place; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public String getSns() { return sns; }
    public void setSns(String sns) { this.sns = sns; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public Map<String, String> getCafeHours() { return cafeHours; }
    public void setCafeHours(Map<String, String> cafeHours) { this.cafeHours = cafeHours; }

    public List<String> getImgURLs() { return imgURLs; }
    public void setImgURLs(List<String> imgURLs) { this.imgURLs = imgURLs; }

    public List<String> getImgNames() { return imgNames; }
    public void setImgNames(List<String> imgNames) { this.imgNames = imgNames; }
}



