package com.example.cafeInfo.Controller;

import com.example.cafeInfo.Entity.CafeDTO;
import com.example.cafeInfo.Entity.CafeImage;
import com.example.cafeInfo.Entity.CafeUploadEntity;
import com.example.cafeInfo.Repository.CafeUploadRepository;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:5173") // 프론트 주소
public class CafeUploadController {

    @Autowired
    private CafeUploadRepository cafeUploadRepository;

    @Value("${file.upload-dir}")
    private String uploadDir;  // ← properties에서 불러옴

    private final String BASE_URL = "http://localhost:8080/images/";

    @PostMapping("/addCafe")
    public ResponseEntity<?> addCafe(
            @RequestPart("cafeData") String cafeData,
            @RequestPart("files") List<MultipartFile> files
    ) {
        List<String> imageUrls = new ArrayList<>();
        List<CafeImage> imageList = new ArrayList<>();

        try {
            ObjectMapper mapper = new ObjectMapper();
            CafeDTO dto = mapper.readValue(cafeData, CafeDTO.class);

            File uploadPath = new File(uploadDir);
            if (!uploadPath.exists()) {
                uploadPath.mkdirs(); // 폴더 없으면 생성
            }

            for (MultipartFile file : files) {
                if (!file.isEmpty()) {
                    String fileName = UUID.randomUUID() + "_" + file.getOriginalFilename();
                    File dest = new File(uploadDir + fileName);
                    file.transferTo(dest);

                    String fileURL = BASE_URL + fileName;
                    imageUrls.add(fileURL);
                    imageList.add(new CafeImage(fileURL, fileName));
                }
            }

            CafeUploadEntity cafe = new CafeUploadEntity();
            cafe.setName(dto.getName());
            cafe.setTitle(dto.getTitle());
            cafe.setPlace(dto.getPlace());
            cafe.setContent(dto.getContent());
            cafe.setSns(dto.getSns());
            cafe.setPhone(dto.getPhone());
            cafe.setCafeHours(dto.getCafeHours());
            cafe.setImages(imageList);

            cafeUploadRepository.save(cafe);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("imageUrls", imageUrls);
            return ResponseEntity.ok(response);

        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body(Map.of("success", false, "message", "카페 등록 중 오류 발생"));
        }
    }

    @GetMapping("/cafes")
    public List<CafeDTO> getCafeList() {
        List<CafeUploadEntity> entities = cafeUploadRepository.findAll();

        return entities.stream().map(entity -> {
            CafeDTO dto = new CafeDTO();
            dto.setId(entity.getId());
            dto.setName(entity.getName());
            dto.setTitle(entity.getTitle());
            dto.setPlace(entity.getPlace());
            dto.setContent(entity.getContent());
            dto.setSns(entity.getSns());
            dto.setPhone(entity.getPhone());
            dto.setCafeHours(entity.getCafeHours());

            List<String> urls = new ArrayList<>();
            List<String> names = new ArrayList<>();
            for (CafeImage img : entity.getImages()) {
                urls.add(img.getImgURL());
                names.add(img.getImgName());
            }
            dto.setImgURLs(urls);
            dto.setImgNames(names);

            return dto;
        }).collect(Collectors.toList());
    }

    // 카페 삭제
    @DeleteMapping("/deleteCafe/{id}")
    public ResponseEntity<String> deleteCafe(@PathVariable Long id) {
        Optional<CafeUploadEntity> cafeOptional = cafeUploadRepository.findById(id);

        if (cafeOptional.isPresent()) {
            CafeUploadEntity cafe = cafeOptional.get();

            // 이미지 삭제: 카페에 연결된 모든 이미지 삭제
            if (cafe.getImages() != null) {
                for (CafeImage image : cafe.getImages()) {
                    // 여기서는 파일명을 사용하여 실제 파일 경로 생성
                    String fileName = image.getImgName();  // 저장시 사용한 파일명
                    File file = new File(uploadDir + fileName);
                    if (file.exists()) {
                        boolean deleted = file.delete();
                        if (!deleted) {
                            // 삭제 실패 시 로그 출력 (실제 서비스에서는 로깅 시스템 활용)
                            System.err.println("파일 삭제 실패: " + file.getAbsolutePath());
                        }
                    }
                }
            }

            // DB에서 카페 데이터 삭제
            cafeUploadRepository.deleteById(id);
            return ResponseEntity.ok("삭제 성공");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("해당 카페가 존재하지 않습니다.");
        }
    }

    // 카페 수정
    // 카페 수정
    @PutMapping("/editCafe/{id}")
    public ResponseEntity<?> editCafe(
            @PathVariable Long id,
            @RequestPart("cafeData") String cafeData,
            @RequestPart(value = "files", required = false) List<MultipartFile> files
    ) {
        Optional<CafeUploadEntity> optionalCafe = cafeUploadRepository.findById(id);

        if (optionalCafe.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("해당 카페가 존재하지 않습니다.");
        }

        try {
            ObjectMapper mapper = new ObjectMapper();
            CafeDTO dto = mapper.readValue(cafeData, CafeDTO.class);

            CafeUploadEntity cafe = optionalCafe.get();

            //  기존 이미지 실제 파일 삭제
            if (cafe.getImages() != null) {
                for (CafeImage img : cafe.getImages()) {
                    String fileName = img.getImgName();
                    File file = new File(uploadDir + fileName);
                    if (file.exists()) {
                        file.delete();
                    }
                }
            }

            //  DB에서 이미지 목록 제거
            cafe.getImages().clear();

            //  새 이미지 처리
            List<CafeImage> newImages = new ArrayList<>();
            if (files != null && !files.isEmpty()) {
                File uploadPath = new File(uploadDir);
                if (!uploadPath.exists()) uploadPath.mkdirs();

                for (MultipartFile file : files) {
                    if (!file.isEmpty()) {
                        String fileName = UUID.randomUUID() + "_" + file.getOriginalFilename();
                        File dest = new File(uploadDir + fileName);
                        file.transferTo(dest);

                        String fileURL = BASE_URL + fileName;
                        newImages.add(new CafeImage(fileURL, fileName));
                    }
                }
            }

            // 새 이미지로 교체
            cafe.setImages(newImages);

            //  나머지 정보 업데이트
            cafe.setName(dto.getName());
            cafe.setTitle(dto.getTitle());
            cafe.setPlace(dto.getPlace());
            cafe.setContent(dto.getContent());
            cafe.setSns(dto.getSns());
            cafe.setPhone(dto.getPhone());
            cafe.setCafeHours(dto.getCafeHours());

            cafeUploadRepository.save(cafe);

            // 클라이언트에 새 이미지 URL 전달 (원하면)
            List<String> imageUrls = newImages.stream().map(CafeImage::getImgURL).collect(Collectors.toList());
            return ResponseEntity.ok(Map.of("success", true, "imageUrls", imageUrls));

        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("카페 수정 중 오류 발생");
        }
    }


    // 카페 수정할 때 데이터
    @GetMapping("/cafe/{id}")
    public ResponseEntity<?> getCafeById(@PathVariable Long id) {
        Optional<CafeUploadEntity> optionalCafe = cafeUploadRepository.findById(id);

        if (optionalCafe.isPresent()) {
            CafeUploadEntity entity = optionalCafe.get();

            CafeDTO dto = new CafeDTO();
            dto.setId(entity.getId());
            dto.setName(entity.getName());
            dto.setTitle(entity.getTitle());
            dto.setPlace(entity.getPlace());
            dto.setContent(entity.getContent());
            dto.setSns(entity.getSns());
            dto.setPhone(entity.getPhone());
            dto.setCafeHours(entity.getCafeHours());

            List<String> imgURLs = new ArrayList<>();
            List<String> imgNames = new ArrayList<>();
            for (CafeImage img : entity.getImages()) {
                imgURLs.add(img.getImgURL());
                imgNames.add(img.getImgName());
            }
            dto.setImgURLs(imgURLs);
            dto.setImgNames(imgNames);

            return ResponseEntity.ok(dto);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("해당 카페가 존재하지 않습니다.");
        }
    }



}
