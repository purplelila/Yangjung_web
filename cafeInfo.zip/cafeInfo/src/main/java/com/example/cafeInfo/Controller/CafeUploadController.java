package com.example.cafeInfo.Controller;

import com.example.cafeInfo.Entity.CafeDTO;
import com.example.cafeInfo.Entity.CafeUploadEntity;

import com.example.cafeInfo.Repository.CafeUploadRepository;
//import com.example.cafeInfo.Service.CafeUploadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:5173") // 프론트 주소
public class CafeUploadController {

    @Autowired
    private CafeUploadRepository cafeUploadRepository;

    @PostMapping("/addCafe")
    public String addCafe(@RequestBody CafeDTO dto) {
        // DTO -> Entity 변환
        CafeUploadEntity  cafe = new CafeUploadEntity ();
        cafe.setName(dto.getName());
        cafe.setTitle(dto.getTitle());
        cafe.setPlace(dto.getPlace());
        cafe.setContent(dto.getContent());
        cafe.setSns(dto.getSns());
        cafe.setPhone(dto.getPhone());
        cafe.setCafeHours(dto.getCafeHours());
        cafe.setImgURLs(dto.getImgURLs());
        cafe.setImgNames(dto.getImgNames());

        cafeUploadRepository.save(cafe);
        return "카페 등록 완료!";
    }
    @GetMapping("/test")
    public String testApi() {
        return "✅ 백엔드 연결 성공!";
    }
}



