package com.example.cafe_lab.admin.lognin;

import com.example.cafe_lab.admin.JwtUtil;
import com.example.cafe_lab.admin.Users;
import com.example.cafe_lab.admin.signup.SignupRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.HashMap;
import java.util.Map;


@Controller
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:5173")
public class LoginController {

    @Autowired
    private LoginService loginService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        String userid = loginRequest.getUserid();
        String password = loginRequest.getPassword();

        System.out.println("📥 로그인 요청 들어옴");
        System.out.println("📌 userid: " + loginRequest.getUserid());
        System.out.println("📌 password: " + loginRequest.getPassword());

        Users user = loginService.login(userid, password); // boolean → User 객체로 수정

        if (user != null) {

            //JWT 토큰 생성
            String token = JwtUtil.generateToken(userid);

            // ✅ 콘솔에 출력
            System.out.println("✅ JWT 생성 완료: " + token);

            Map<String, Object> response = new HashMap<>();
            response.put("message", "로그인 성공");
            response.put("userType", user.getUserType()); // userType: 0, 1, 3
            response.put("token", token); // 토큰 추가!

            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.status(401).body("아이디 또는 비밀번호가 틀렸습니다.");
        }
    }
}

