package com.example.cafe_lab.admin.signup;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "http://localhost:5173")
public class SignupController {

    @Autowired
    private com.example.cafe_lab.admin.signup.SignupService signupService;

    @PostMapping("/signup")
    public ResponseEntity<String> registerUser(@RequestBody com.example.cafe_lab.admin.signup.SignupRequest request) {
        System.out.println("회원가입 요청: " + request);
        String result = signupService.registerUser(request);
        return ResponseEntity.ok(result);
    }
}