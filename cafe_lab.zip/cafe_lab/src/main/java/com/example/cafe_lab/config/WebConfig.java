package com.example.cafe_lab.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Value("${file.upload-dir}")
    private String uploadDir;

    // CORS 설정
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")  // 모든 엔드포인트에 적용
                .allowedOrigins("http://localhost:5173") // 프론트엔드 주소
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);
    }

    // 정적 리소스 경로 설정 (업로드 이미지 접근 가능하도록)
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // /images/** 로 접근 시 실제 업로드 폴더를 참조
        registry.addResourceHandler("/images/**")
                .addResourceLocations("file:///" + uploadDir.replace("\\", "/") + "/");
    }
}
