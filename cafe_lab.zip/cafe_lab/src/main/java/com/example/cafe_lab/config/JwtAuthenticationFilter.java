package com.example.cafe_lab.config;

import com.example.cafe_lab.admin.CustomUserDetailsService;
import com.example.cafe_lab.admin.JwtUtil;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final CustomUserDetailsService userDetailsService;

    public JwtAuthenticationFilter(CustomUserDetailsService userDetailsService) {
        this.userDetailsService = userDetailsService;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        String header = request.getHeader("Authorization");
        System.out.println("JWT Header: " + header);  // 헤더가 제대로 전달되었는지 확인하는 로그

        if (header != null && header.startsWith("Bearer ")) {
            String token = header.substring(7);
            System.out.println("Received token: " + token); // 추가된 로그

            if (JwtUtil.validateToken(token)) {
                // 토큰이 유효하다면, 유저 아이디를 출력하여 토큰에서 정보를 잘 추출하는지 확인
                System.out.println("JWT 유효함. 유저 아이디: " + JwtUtil.getUseridFromToken(token));

                String userid = JwtUtil.getUseridFromToken(token);
                UserDetails userDetails = userDetailsService.loadUserByUsername(userid);

                UsernamePasswordAuthenticationToken authentication =
                        new UsernamePasswordAuthenticationToken(
                                userDetails, null, userDetails.getAuthorities());

                authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                SecurityContextHolder.getContext().setAuthentication(authentication);
            } else {
                // 유효하지 않은 토큰에 대해 로그 추가 후 401 Unauthorized 응답
                System.out.println("JWT 토큰이 유효하지 않음");
                response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Invalid or expired token");
                return;  // 필터 체인 종료
            }
        }

        filterChain.doFilter(request, response);  // 필터 체인을 계속 진행
    }
}


