package com.example.cafe_lab.cafeInfo.Repository;

import com.example.cafe_lab.cafeInfo.Entity.CafeUploadEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CafeUploadRepository extends JpaRepository<CafeUploadEntity, Long> {
}
