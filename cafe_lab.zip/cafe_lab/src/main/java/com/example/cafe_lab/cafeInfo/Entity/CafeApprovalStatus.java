package com.example.cafe_lab.cafeInfo.Entity;

public enum CafeApprovalStatus {
    PENDING,   // 대기
    APPROVED,  // 승인
    REJECTED   // 거절
}
