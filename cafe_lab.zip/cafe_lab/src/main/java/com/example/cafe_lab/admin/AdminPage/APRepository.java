package com.example.cafe_lab.admin.AdminPage;

import com.example.cafe_lab.admin.Users;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface APRepository extends JpaRepository<Users, Long> {
    List<Users> findByUserType(int userType);
}
