package com.example.cafe_lab.admin.lognin;

import com.example.cafe_lab.admin.Users;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoginService {
    @Autowired
    private LoginRepository loginRepository;

    public Users login(String userid, String password) {
        Users user = loginRepository.findByUserid(userid).orElse(null);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }
}