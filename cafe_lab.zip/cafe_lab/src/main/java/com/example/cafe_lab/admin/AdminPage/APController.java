package com.example.cafe_lab.admin.AdminPage;

import com.example.cafe_lab.admin.Users;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class APController {

    private final com.example.cafe_lab.admin.AdminPage.APRepository apRepository;

    //  생성자 주입
    @Autowired
    public APController(com.example.cafe_lab.admin.AdminPage.APRepository apRepository) {
        this.apRepository = apRepository;
    }

    //  userType이 0인 회원 목록 반환
    @GetMapping()
    public List<Users> getUsersByType(@RequestParam int userType) {
        return apRepository.findByUserType(userType);
    }


}
